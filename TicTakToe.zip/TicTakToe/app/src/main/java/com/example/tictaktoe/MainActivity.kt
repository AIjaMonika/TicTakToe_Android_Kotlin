//GitHub links: https://github.com/AIjaMonika/TicTakToe_Android_Kotlin
//Used sources:
//https://www.youtube.com/watch?v=POFvcoRo3Vw
//https://github.com/mariscallzn/KotlinTicTacToe
//the code was written by hand, but mostly following the youtube tutorial
package com.example.tictaktoe
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.tictaktoe.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    enum class Turn
    {
        CIRCLE,
        CROSS
    }

    enum class Mode
    {
        PvC,
        PvP
    }

    private var firstTurn = Turn.CROSS
    private var currentTurn = Turn.CROSS
    private var mode = Mode.PvP
    private var boardList = mutableListOf<Button>()

    private var crossesScore = 0
    private var circlesScore = 0

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initBoard()
    }

    private fun initBoard() {
        greetingMessage()
        boardList.add(binding.a1)
        boardList.add(binding.a2)
        boardList.add(binding.a3)
        boardList.add(binding.b1)
        boardList.add(binding.b2)
        boardList.add(binding.b3)
        boardList.add(binding.c1)
        boardList.add(binding.c2)
        boardList.add(binding.c3)
    }

    fun boardTapped(view: View){
        if (view !is Button)
            return
        if (mode == Mode.PvC){
            if (currentTurn == Turn.CROSS){
            for (button in boardList) {
                if (button.text == "") {
                    addToBoard(button)
                    return
                }


            }
            }
            else{
                addToBoard(view)
            }
        }
        else {
            addToBoard(view)
        }
        if(checkForVictory(CROSS)){
            crossesScore++
            result("Crosses win!")

        }
        else if(checkForVictory(CIRCLE)){
            circlesScore++
            result ("Circles win!")
        }
        if (fullBoard()){
            result("Draw")
        }
    }

    private fun checkForVictory(sym: String): Boolean {
        //if a horizontal line of equivalent symbols
        if (match(binding.a1,sym) && match(binding.a2,sym) && match(binding.a3,sym))
            return true
        if (match(binding.b1,sym) && match(binding.b2,sym) && match(binding.b3,sym))
            return true
        if (match(binding.c1,sym) && match(binding.c2,sym) && match(binding.c3,sym))
            return true

        //if a vertical line of equivalent symbols
        if (match(binding.a1,sym) && match(binding.b1,sym) && match(binding.c1,sym))
            return true
        if (match(binding.a2,sym) && match(binding.b2,sym) && match(binding.c2,sym))
            return true
        if (match(binding.a3,sym) && match(binding.b3,sym) && match(binding.c3,sym))
            return true

        //if a diagonal of equivalent symbols
        if (match(binding.a1,sym) && match(binding.b2,sym) && match(binding.c3,sym))
            return true
        if (match(binding.a3,sym) && match(binding.b2,sym) && match(binding.c1,sym))
            return true

        return false
    }
    private fun match(button: Button, symbol: String): Boolean = button.text == symbol

    private fun result(title: String) {
        val message = "\n Crosses = $crossesScore \n\n Circles = $circlesScore"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Reset"){
                    _,_ ->
                resetBoard()
            }
            .setCancelable(false)
            .show()
    }

    private fun resetBoard() {
        for (button in boardList){
            button.text = ""
        }
        if(firstTurn == Turn.CIRCLE)
            firstTurn = Turn.CROSS
        else if(firstTurn == Turn.CROSS)
            firstTurn = Turn.CIRCLE

        currentTurn = firstTurn
        setTurnLabel()
    }

    private fun greetingMessage(){
        AlertDialog.Builder(this)
            .setTitle("Hello!")
            .setMessage("This is Tic Tak Toe made by Aija Monika Vainiņa")
            .setPositiveButton("Start"){
                    _,_ ->
                whichMode()
            }
            .setCancelable(false)
            .show()
    }

    private fun whichMode() {
        AlertDialog.Builder(this)
            .setTitle("Choose mode!")
            .setPositiveButton("PvP"){
                    _,_ ->
                mode = Mode.PvP
                resetBoard()
            }
            .setNegativeButton("PvC"){
                    _,_ ->
                mode = Mode.PvC //because I am lazy in PvC computer is always X
                resetBoard()
            }
            .setCancelable(false)
            .show()
    }

    private fun fullBoard(): Boolean {
        for (button in boardList){
            if (button.text == "")
                return false
        }
        return true
    }

    private fun addToBoard(button: Button) {
        if (button.text !="")
            return
        if (currentTurn == Turn.CIRCLE) {
            button.text = CIRCLE
            currentTurn = Turn.CROSS
        } else if (currentTurn == Turn.CROSS) {
            button.text = CROSS
            currentTurn = Turn.CIRCLE
        }
        setTurnLabel()
        }


    private fun setTurnLabel() {
        var turnText = ""
        if(currentTurn == Turn.CROSS){
            turnText = "Turn $CROSS"
        }
        else if(currentTurn == Turn.CIRCLE){
            turnText = "Turn $CIRCLE"
        }

        binding.turnTV.text = turnText
    }

    companion object{
        const val CIRCLE = "0"
        const val CROSS = "X"
    }
}